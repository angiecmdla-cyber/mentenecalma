# PAUSA — Aprende a Manejar la Ansiedad

Mini app educativa y de acompañamiento.

## GitHub Pages
Subí estos archivos a un repositorio y activá GitHub Pages desde Settings > Pages.

## Checkout
En `app.js`, reemplazá el `alert('Acá podés colocar tu enlace de checkout.')` del botón de compra por tu URL real.

Los registros se guardan localmente con localStorage.
